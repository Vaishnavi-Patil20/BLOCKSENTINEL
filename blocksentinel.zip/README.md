# BlockSentinel — Blockchain Intelligence Command Center

A full-stack enterprise-grade blockchain risk intelligence platform for monitoring, analyzing, and investigating Ethereum transactions in real time.

## Architecture

```
blocksentinel/
├── backend/          # Node.js + Express + SQLite + Alchemy API
│   ├── server.js
│   ├── config/
│   ├── routes/
│   ├── services/
│   └── middleware/
└── frontend/         # React + Vite + Tailwind + Three.js
    ├── src/
    │   ├── pages/
    │   ├── components/
    │   ├── hooks/
    │   ├── services/
    │   └── store/
```

## Features

- **Real-time Monitoring**: Live Ethereum transaction feed via Alchemy WebSocket
- **Risk Engine**: AI-powered risk scoring with explainable factors
- **Wallet Intelligence**: On-chain balance, transaction history, counterparty analysis
- **Transaction Graph**: Interactive 3D network visualization
- **Alert Center**: Severity-based alert management
- **Investigations**: Case creation and management workspace
- **Aegis AI**: AI-assisted blockchain intelligence queries
- **Analytics**: Risk distribution, trends, volume charts
- **Audit Trail**: Immutable action logging
- **Settings**: Risk thresholds, notifications, appearance
- **Global Search**: Cross-entity search (transactions, wallets, cases, alerts)
- **Command Palette**: Ctrl+K quick navigation

## Setup

### 1. Backend

```bash
cd backend
npm install
```

Edit `.env`:
```
ALCHEMY_API_KEY=your_real_alchemy_api_key
ALCHEMY_NETWORK=eth-mainnet
JWT_SECRET=your_jwt_secret
PORT=5000
FRONTEND_URL=http://localhost:5173
```

```bash
npm start
```

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

### 3. Access

- Landing: http://localhost:5173
- API: http://localhost:5000/api
- Login/Signup to access the Command Center

## Real Data Policy

BlockSentinel uses **only real data from Alchemy**:
- Live transaction feeds from Ethereum Mainnet
- Real wallet balances and transaction counts
- Actual block data and gas prices
- On-chain transfer history via `alchemy_getAssetTransfers`

No fabricated, simulated, or randomly generated transaction data is used.

## Tech Stack

**Backend**: Node.js, Express, SQLite (better-sqlite3), JWT, bcrypt, WebSocket, Alchemy SDK
**Frontend**: React 18, Vite, Tailwind CSS, Framer Motion, Three.js, Recharts, Zustand, Axios

## License

MIT
