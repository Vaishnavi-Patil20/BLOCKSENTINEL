const express = require('express');
const db = require('../config/database');
const alchemyService = require('../services/alchemy');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

router.get('/', authenticate, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 3) {
      return res.json({ results: [] });
    }

    const results = [];
    const query = `%${q}%`;

    // Search transactions
    const txs = db.prepare(`
      SELECT tx_hash as id, 'transaction' as type, tx_hash as title, risk_level as subtitle
      FROM transactions WHERE tx_hash LIKE ? LIMIT 5
    `).all(query);
    results.push(...txs);

    // Search wallets
    const wallets = db.prepare(`
      SELECT address as id, 'wallet' as type, address as title, risk_level as subtitle
      FROM wallet_intel WHERE address LIKE ? LIMIT 5
    `).all(query);
    results.push(...wallets);

    // Search cases
    const cases = db.prepare(`
      SELECT id, 'case' as type, case_number as title, status as subtitle
      FROM cases WHERE case_number LIKE ? OR title LIKE ? LIMIT 5
    `).all(query, query);
    results.push(...cases);

    // Search alerts
    const alerts = db.prepare(`
      SELECT id, 'alert' as type, title, severity as subtitle
      FROM alerts WHERE title LIKE ? OR tx_hash LIKE ? LIMIT 5
    `).all(query, query);
    results.push(...alerts);

    res.json({ results });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
