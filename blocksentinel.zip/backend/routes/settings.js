const express = require('express');
const db = require('../config/database');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

router.get('/', authenticate, (req, res) => {
  try {
    const settings = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(req.user.id);
    if (!settings) {
      db.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(req.user.id);
      const newSettings = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(req.user.id);
      return res.json(newSettings);
    }
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put('/', authenticate, (req, res) => {
  try {
    const { risk_threshold_low, risk_threshold_medium, risk_threshold_high, alert_enabled, notifications_enabled, theme } = req.body;

    const fields = [];
    const values = [];

    if (risk_threshold_low !== undefined) { fields.push('risk_threshold_low = ?'); values.push(risk_threshold_low); }
    if (risk_threshold_medium !== undefined) { fields.push('risk_threshold_medium = ?'); values.push(risk_threshold_medium); }
    if (risk_threshold_high !== undefined) { fields.push('risk_threshold_high = ?'); values.push(risk_threshold_high); }
    if (alert_enabled !== undefined) { fields.push('alert_enabled = ?'); values.push(alert_enabled ? 1 : 0); }
    if (notifications_enabled !== undefined) { fields.push('notifications_enabled = ?'); values.push(notifications_enabled ? 1 : 0); }
    if (theme) { fields.push('theme = ?'); values.push(theme); }

    values.push(req.user.id);

    db.prepare(`UPDATE user_settings SET ${fields.join(', ')} WHERE user_id = ?`).run(...values);

    const updated = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(req.user.id);
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
