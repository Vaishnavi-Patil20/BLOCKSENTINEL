import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bot, Send, User, Sparkles } from 'lucide-react';
import { analyticsAPI } from '../services/api';

const AiIntelligence = () => {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hello, I am Aegis AI. I can help you analyze blockchain intelligence data. Ask me about transactions, wallets, risk scores, or alerts.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setInput('');
    setLoading(true);

    // Simple rule-based responses using real data
    let response = '';
    const lower = userMsg.toLowerCase();

    try {
      if (lower.includes('highest risk') || lower.includes('top risk')) {
        const res = await analyticsAPI.dashboard();
        const highRisk = res.data.recentHighRisk?.slice(0, 5) || [];
        response = `I found ${highRisk.length} high-risk transactions recently:
` + 
          highRisk.map((tx, i) => `${i+1}. ${tx.tx_hash?.slice(0, 20)}... (Risk: ${tx.risk_score}/100)`).join('
');
      } else if (lower.includes('alert') || lower.includes('critical')) {
        const res = await analyticsAPI.dashboard();
        const alerts = res.data.alerts;
        response = `Current alert status:
- Critical: ${alerts.critical || 0}
- High: ${alerts.high || 0}
- Medium: ${alerts.medium || 0}
- Low: ${alerts.low || 0}`;
      } else if (lower.includes('transaction') && lower.includes('count')) {
        const res = await analyticsAPI.dashboard();
        response = `Total transactions analyzed: ${res.data.transactions.total?.toLocaleString() || 0}. Average risk score: ${Math.round(res.data.transactions.avg_risk || 0)}/100.`;
      } else if (lower.includes('block')) {
        const res = await analyticsAPI.dashboard();
        response = `Latest block: #${res.data.latestBlock?.number?.toLocaleString() || 'N/A'}. Network: ${res.data.dataSource?.network || 'Ethereum Mainnet'}.`;
      } else if (lower.includes('help') || lower.includes('what can you')) {
        response = 'I can answer questions about:
- Highest risk transactions and wallets
- Alert statistics and distribution
- Transaction counts and averages
- Latest block information
- Risk trends

Try asking: "Show me the highest risk wallets" or "How many critical alerts?"';
      } else {
        response = 'I understand you want to know about: "' + userMsg + '"

I can analyze blockchain data for you. Try asking about:
- Risk scores
- Alert counts
- Transaction statistics
- Latest blocks';
      }
    } catch (e) {
      response = 'I encountered an error fetching blockchain data. Please ensure the backend is connected to Alchemy.';
    }

    setTimeout(() => {
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      setLoading(false);
    }, 800);
  };

  return (
    <div className="space-y-4 h-[calc(100vh-120px)] flex flex-col">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-sentinel-accent/10 rounded-full flex items-center justify-center">
          <Bot size={20} className="text-sentinel-accent" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Aegis AI</h1>
          <p className="text-xs text-gray-500">AI-Assisted Blockchain Intelligence</p>
        </div>
      </div>

      <div className="flex-1 card overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto space-y-4 p-4">
          {messages.map((msg, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 bg-sentinel-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Sparkles size={14} className="text-sentinel-accent" />
                </div>
              )}
              <div className={`max-w-[80%] p-3 rounded-xl ${msg.role === 'user' ? 'bg-sentinel-accent text-white' : 'bg-sentinel-900/50 text-gray-300'}`}>
                <div className="text-sm whitespace-pre-line">{msg.content}</div>
              </div>
              {msg.role === 'user' && (
                <div className="w-8 h-8 bg-sentinel-700 rounded-full flex items-center justify-center flex-shrink-0">
                  <User size={14} />
                </div>
              )}
            </motion.div>
          ))}
          {loading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 bg-sentinel-accent/10 rounded-full flex items-center justify-center">
                <Sparkles size={14} className="text-sentinel-accent animate-pulse" />
              </div>
              <div className="bg-sentinel-900/50 p-3 rounded-xl">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>

        <form onSubmit={handleSend} className="p-4 border-t border-sentinel-600/20 flex gap-2">
          <input
            type="text"
            className="input-field flex-1"
            placeholder="Ask Aegis AI about blockchain intelligence..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button type="submit" disabled={loading} className="btn-primary px-4">
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};

export default AiIntelligence;
