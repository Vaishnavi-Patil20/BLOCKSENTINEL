import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Filter, CheckCircle, Clock, Shield } from 'lucide-react';
import { alertAPI } from '../services/api';

const Alerts = () => {
  const [alerts, setAlerts] = useState([]);
  const [stats, setStats] = useState({});
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
    loadStats();
  }, []);

  const loadAlerts = async () => {
    try {
      const res = await alertAPI.list({ limit: 50 });
      setAlerts(res.data.alerts || []);
    } catch (e) {} finally { setLoading(false); }
  };

  const loadStats = async () => {
    try {
      const res = await alertAPI.stats();
      setStats(res.data || {});
    } catch (e) {}
  };

  const resolveAlert = async (id) => {
    try {
      await alertAPI.updateStatus(id, 'resolved');
      loadAlerts();
      loadStats();
    } catch (e) {}
  };

  const filtered = filter === 'all' ? alerts : alerts.filter(a => a.severity === filter);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2"><AlertTriangle size={24} className="text-sentinel-high" />Alert Intelligence</h1>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-gray-500" />
          <select className="input-field text-sm py-2" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'CRITICAL', value: stats.critical || 0, color: 'text-red-400', bg: 'bg-red-500/10' },
          { label: 'HIGH', value: stats.high || 0, color: 'text-orange-400', bg: 'bg-orange-500/10' },
          { label: 'MEDIUM', value: stats.medium || 0, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
          { label: 'LOW', value: stats.low || 0, color: 'text-green-400', bg: 'bg-green-500/10' },
        ].map((s, i) => (
          <div key={i} className={`${s.bg} border border-sentinel-600/20 rounded-xl p-5 text-center`}>
            <div className={`text-3xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-sm text-gray-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        {loading && <div className="text-center py-12 text-gray-500">Loading alerts...</div>}
        {!loading && filtered.length === 0 && <div className="text-center py-12 text-gray-500">No alerts found</div>}
        <div className="space-y-3">
          {filtered.map((alert, i) => (
            <motion.div key={alert.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="flex items-center justify-between p-4 bg-sentinel-900/50 rounded-lg border-l-4 border-l-transparent hover:border-l-sentinel-accent transition-all">
              <div className="flex items-start gap-4">
                <div className={`p-2 rounded-lg ${alert.severity === 'CRITICAL' ? 'bg-red-500/10' : alert.severity === 'HIGH' ? 'bg-orange-500/10' : alert.severity === 'MEDIUM' ? 'bg-yellow-500/10' : 'bg-green-500/10'}`}>
                  <AlertTriangle size={18} className={alert.severity === 'CRITICAL' ? 'text-red-400' : alert.severity === 'HIGH' ? 'text-orange-400' : alert.severity === 'MEDIUM' ? 'text-yellow-400' : 'text-green-400'} />
                </div>
                <div>
                  <div className="font-medium text-gray-200">{alert.title}</div>
                  <div className="text-sm text-gray-500 mt-0.5">{alert.description}</div>
                  <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1"><Clock size={12} />{new Date(alert.created_at).toLocaleString()}</span>
                    <span className="font-mono">{alert.tx_hash?.slice(0, 16)}...</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`badge badge-${alert.severity?.toLowerCase()}`}>{alert.severity}</span>
                <span className="text-sm font-mono text-gray-300">{alert.risk_score}/100</span>
                {alert.status === 'open' && (
                  <button onClick={() => resolveAlert(alert.id)} className="p-2 hover:bg-green-500/10 rounded-lg text-green-400" title="Resolve">
                    <CheckCircle size={18} />
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Alerts;
