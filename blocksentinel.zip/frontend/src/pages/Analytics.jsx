import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, PieChart, Activity } from 'lucide-react';
import { analyticsAPI } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RePieChart, Pie, Cell, LineChart, Line } from 'recharts';

const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e'];

const Analytics = () => {
  const [data, setData] = useState(null);
  const [trends, setTrends] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashRes, trendRes] = await Promise.all([analyticsAPI.dashboard(), analyticsAPI.riskTrend()]);
      setData(dashRes.data);
      setTrends(trendRes.data || []);
    } catch (e) {} finally { setLoading(false); }
  };

  const riskDistData = data?.riskDistribution?.map(d => ({ name: d.risk_level, value: d.count })) || [];
  const trendData = trends.map(t => ({ date: t.date, avgRisk: Math.round(t.avg_risk || 0), txCount: t.tx_count || 0 }));

  if (loading) return <div className="text-center py-12 text-gray-500">Loading analytics...</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold flex items-center gap-2"><BarChart3 size={24} className="text-sentinel-accent" />Analytics</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card">
          <div className="flex items-center gap-2 mb-2"><Activity size={18} className="text-sentinel-accent" /><span className="text-sm text-gray-500">Total Transactions</span></div>
          <div className="text-3xl font-bold">{data?.transactions?.total?.toLocaleString() || 0}</div>
        </div>
        <div className="card">
          <div className="flex items-center gap-2 mb-2"><TrendingUp size={18} className="text-sentinel-high" /><span className="text-sm text-gray-500">Avg Risk Score</span></div>
          <div className="text-3xl font-bold">{Math.round(data?.transactions?.avg_risk || 0)}<span className="text-lg text-gray-500">/100</span></div>
        </div>
        <div className="card">
          <div className="flex items-center gap-2 mb-2"><PieChart size={18} className="text-green-400" /><span className="text-sm text-gray-500">Critical Alerts</span></div>
          <div className="text-3xl font-bold text-sentinel-critical">{data?.alerts?.critical || 0}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-bold mb-4">Risk Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RePieChart>
              <Pie data={riskDistData} cx="50%" cy="50%" outerRadius={100} dataKey="value" label>
                {riskDistData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1a1a25', border: '1px solid #2a2a3c', borderRadius: '8px' }} />
            </RePieChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="font-bold mb-4">Risk Trend (7 Days)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3c" />
              <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
              <YAxis stroke="#6b7280" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#1a1a25', border: '1px solid #2a2a3c', borderRadius: '8px' }} />
              <Line type="monotone" dataKey="avgRisk" stroke="#6366f1" strokeWidth={2} dot={{ fill: '#6366f1' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h3 className="font-bold mb-4">Transaction Volume</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3c" />
            <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
            <YAxis stroke="#6b7280" fontSize={12} />
            <Tooltip contentStyle={{ backgroundColor: '#1a1a25', border: '1px solid #2a2a3c', borderRadius: '8px' }} />
            <Bar dataKey="txCount" fill="#6366f1" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Analytics;
