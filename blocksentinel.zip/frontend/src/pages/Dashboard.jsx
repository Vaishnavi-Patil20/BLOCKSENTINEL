import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, AlertTriangle, Shield, BarChart3, TrendingUp, Blocks } from 'lucide-react';
import { analyticsAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const StatCard = ({ title, value, sub, icon: Icon, color, onClick }) => (
  <motion.div whileHover={{ y: -2 }} onClick={onClick} className={`card cursor-pointer hover:border-${color}-500/30 transition-all`}>
    <div className="flex items-start justify-between mb-3">
      <div className={`p-2 rounded-lg bg-${color}-500/10`}><Icon size={20} className={`text-${color}-400`} /></div>
      {sub && <span className="text-xs text-gray-500">{sub}</span>}
    </div>
    <div className="text-2xl font-bold text-white mb-1">{value}</div>
    <div className="text-sm text-gray-500">{title}</div>
  </motion.div>
);

const Dashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    analyticsAPI.dashboard().then(res => { setData(res.data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64 text-gray-500">Loading intelligence...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Command Center</h1>
          <p className="text-gray-500 text-sm">Live blockchain intelligence overview</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-400 bg-sentinel-800 px-4 py-2 rounded-lg border border-sentinel-600/20">
          <Blocks size={16} className="text-green-400" />
          <span>Block #{data?.latestBlock?.number?.toLocaleString() || '...'}</span>
          <span className="text-gray-600">|</span>
          <span className="text-green-400">● Live</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Transactions Analyzed" value={data?.transactions?.total?.toLocaleString() || '0'} icon={Activity} color="blue" sub="All time" onClick={() => navigate('/transactions')} />
        <StatCard title="Critical Risk" value={data?.transactions?.critical || '0'} icon={AlertTriangle} color="red" sub="Requires attention" onClick={() => navigate('/alerts')} />
        <StatCard title="High Risk" value={data?.transactions?.high || '0'} icon={Shield} color="orange" sub="Monitor closely" onClick={() => navigate('/alerts')} />
        <StatCard title="Avg Risk Score" value={Math.round(data?.transactions?.avg_risk || 0)} icon={BarChart3} color="purple" sub="/100" onClick={() => navigate('/analytics')} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <h3 className="font-bold mb-4 flex items-center gap-2"><TrendingUp size={18} className="text-sentinel-accent" />Recent High-Risk Transactions</h3>
          <div className="space-y-2">
            {data?.recentHighRisk?.length === 0 && <div className="text-gray-500 text-sm py-8 text-center">No high-risk transactions detected yet</div>}
            {data?.recentHighRisk?.map((tx, i) => (
              <div key={i} onClick={() => navigate(`/transactions/${tx.tx_hash}`)} className="flex items-center justify-between p-3 bg-sentinel-900/50 rounded-lg hover:bg-sentinel-700/30 cursor-pointer transition-all">
                <div>
                  <div className="font-mono text-sm text-gray-300">{tx.tx_hash?.slice(0, 20)}...</div>
                  <div className="text-xs text-gray-500 mt-0.5">{tx.from_address?.slice(0, 16)}... → {tx.to_address?.slice(0, 16)}...</div>
                </div>
                <div className="text-right">
                  <div className={`badge badge-${tx.risk_level?.toLowerCase()}`}>{tx.risk_level}</div>
                  <div className="text-sm font-mono mt-1 text-gray-300">{parseFloat(tx.value_eth || 0).toFixed(4)} ETH</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="card">
            <h3 className="font-bold mb-3">Alert Distribution</h3>
            <div className="space-y-3">
              {[
                { label: 'Critical', value: data?.alerts?.critical || 0, color: 'bg-red-500' },
                { label: 'High', value: data?.alerts?.high || 0, color: 'bg-orange-500' },
                { label: 'Medium', value: data?.alerts?.medium || 0, color: 'bg-yellow-500' },
                { label: 'Low', value: data?.alerts?.low || 0, color: 'bg-green-500' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">{item.label}</span>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-2 bg-sentinel-900 rounded-full overflow-hidden"><div className={`h-full ${item.color} rounded-full`} style={{ width: `${Math.min(100, (item.value / 10) * 100)}%` }}></div></div>
                    <span className="text-sm font-mono w-6 text-right">{item.value}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold mb-3">Case Status</h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div><div className="text-xl font-bold text-yellow-400">{data?.cases?.open || 0}</div><div className="text-xs text-gray-500">Open</div></div>
              <div><div className="text-xl font-bold text-sentinel-accent">{data?.cases?.investigating || 0}</div><div className="text-xs text-gray-500">Investigating</div></div>
              <div><div className="text-xl font-bold text-green-400">{data?.cases?.resolved || 0}</div><div className="text-xs text-gray-500">Resolved</div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
