import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Microscope, Plus, Search, FileText, User, Calendar, Flag } from 'lucide-react';
import { caseAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const Investigations = () => {
  const [cases, setCases] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newCase, setNewCase] = useState({ title: '', description: '', priority: 'MEDIUM' });
  const navigate = useNavigate();

  useEffect(() => { loadCases(); }, []);

  const loadCases = async () => {
    try { const res = await caseAPI.list(); setCases(res.data || []); } catch (e) {}
  };

  const createCase = async (e) => {
    e.preventDefault();
    try { await caseAPI.create(newCase); setShowCreate(false); setNewCase({ title: '', description: '', priority: 'MEDIUM' }); loadCases(); }
    catch (e) { alert('Failed to create case'); }
  };

  const getPriorityColor = (p) => {
    if (p === 'CRITICAL') return 'text-red-400 bg-red-500/10 border-red-500/20';
    if (p === 'HIGH') return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
    if (p === 'MEDIUM') return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
    return 'text-green-400 bg-green-500/10 border-green-500/20';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Microscope size={24} className="text-sentinel-accent" />Investigations</h1>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2"><Plus size={18} /> Create Case</button>
      </div>

      {showCreate && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="card">
          <h3 className="font-bold mb-4">Create New Investigation</h3>
          <form onSubmit={createCase} className="space-y-4">
            <input required className="input-field" placeholder="Case Title" value={newCase.title} onChange={e => setNewCase({...newCase, title: e.target.value})} />
            <textarea className="input-field" rows={3} placeholder="Description" value={newCase.description} onChange={e => setNewCase({...newCase, description: e.target.value})} />
            <select className="input-field" value={newCase.priority} onChange={e => setNewCase({...newCase, priority: e.target.value})}>
              <option value="CRITICAL">Critical</option>
              <option value="HIGH">High</option>
              <option value="MEDIUM">Medium</option>
              <option value="LOW">Low</option>
            </select>
            <div className="flex gap-2">
              <button type="submit" className="btn-primary">Create</button>
              <button type="button" onClick={() => setShowCreate(false)} className="btn-secondary">Cancel</button>
            </div>
          </form>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-3">
          <h3 className="font-bold text-gray-400 text-sm uppercase tracking-wider">Active Cases</h3>
          {cases.length === 0 && <div className="text-gray-500 text-sm py-4">No cases yet</div>}
          {cases.map((c, i) => (
            <motion.div key={c.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
              className="card p-4 cursor-pointer hover:border-sentinel-accent/30 transition-all">
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-sm text-sentinel-accent">{c.case_number}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full border ${getPriorityColor(c.priority)}`}>{c.priority}</span>
              </div>
              <div className="font-medium text-gray-200 mb-1">{c.title}</div>
              <div className="text-xs text-gray-500">{c.status}</div>
            </motion.div>
          ))}
        </div>

        <div className="lg:col-span-2 card">
          <h3 className="font-bold mb-4 flex items-center gap-2"><Search size={18} className="text-sentinel-accent" />Investigation Workspace</h3>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-sentinel-900/50 p-4 rounded-lg text-center">
              <FileText size={24} className="mx-auto mb-2 text-sentinel-accent" />
              <div className="text-2xl font-bold">{cases.length}</div>
              <div className="text-xs text-gray-500">Total Cases</div>
            </div>
            <div className="bg-sentinel-900/50 p-4 rounded-lg text-center">
              <Flag size={24} className="mx-auto mb-2 text-sentinel-high" />
              <div className="text-2xl font-bold">{cases.filter(c => c.status === 'Open').length}</div>
              <div className="text-xs text-gray-500">Open</div>
            </div>
          </div>
          <div className="border-t border-sentinel-600/20 pt-4">
            <div className="text-sm text-gray-500 text-center py-8">Select a case to view details or create a new investigation</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Investigations;
