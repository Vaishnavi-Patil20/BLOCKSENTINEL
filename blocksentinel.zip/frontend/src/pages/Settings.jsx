import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Shield, Bell, Palette, Database, Save } from 'lucide-react';
import { settingsAPI } from '../services/api';

const SettingsPage = () => {
  const [settings, setSettings] = useState({
    risk_threshold_low: 30,
    risk_threshold_medium: 60,
    risk_threshold_high: 80,
    alert_enabled: true,
    notifications_enabled: true,
    theme: 'dark'
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const res = await settingsAPI.get();
      setSettings({
        risk_threshold_low: res.data.risk_threshold_low || 30,
        risk_threshold_medium: res.data.risk_threshold_medium || 60,
        risk_threshold_high: res.data.risk_threshold_high || 80,
        alert_enabled: res.data.alert_enabled === 1,
        notifications_enabled: res.data.notifications_enabled === 1,
        theme: res.data.theme || 'dark'
      });
    } catch (e) {}
  };

  const save = async () => {
    setSaving(true);
    try {
      await settingsAPI.update({
        risk_threshold_low: settings.risk_threshold_low,
        risk_threshold_medium: settings.risk_threshold_medium,
        risk_threshold_high: settings.risk_threshold_high,
        alert_enabled: settings.alert_enabled,
        notifications_enabled: settings.notifications_enabled,
        theme: settings.theme
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e) {} finally { setSaving(false); }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold flex items-center gap-2"><Settings size={24} className="text-sentinel-accent" />Settings</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Shield size={18} className="text-sentinel-accent" />Risk Thresholds</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2"><span className="text-sm text-gray-400">Low Risk Threshold</span><span className="text-sm font-mono">{settings.risk_threshold_low}/100</span></div>
                <input type="range" min="0" max="100" value={settings.risk_threshold_low} onChange={e => setSettings({...settings, risk_threshold_low: parseInt(e.target.value)})} className="w-full accent-sentinel-accent" />
              </div>
              <div>
                <div className="flex justify-between mb-2"><span className="text-sm text-gray-400">Medium Risk Threshold</span><span className="text-sm font-mono">{settings.risk_threshold_medium}/100</span></div>
                <input type="range" min="0" max="100" value={settings.risk_threshold_medium} onChange={e => setSettings({...settings, risk_threshold_medium: parseInt(e.target.value)})} className="w-full accent-sentinel-accent" />
              </div>
              <div>
                <div className="flex justify-between mb-2"><span className="text-sm text-gray-400">High Risk Threshold</span><span className="text-sm font-mono">{settings.risk_threshold_high}/100</span></div>
                <input type="range" min="0" max="100" value={settings.risk_threshold_high} onChange={e => setSettings({...settings, risk_threshold_high: parseInt(e.target.value)})} className="w-full accent-sentinel-accent" />
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Bell size={18} className="text-sentinel-accent" />Notifications</h3>
            <div className="space-y-3">
              <label className="flex items-center justify-between p-3 bg-sentinel-900/50 rounded-lg cursor-pointer">
                <span className="text-sm text-gray-300">Alert Notifications</span>
                <input type="checkbox" checked={settings.alert_enabled} onChange={e => setSettings({...settings, alert_enabled: e.target.checked})} className="w-5 h-5 accent-sentinel-accent" />
              </label>
              <label className="flex items-center justify-between p-3 bg-sentinel-900/50 rounded-lg cursor-pointer">
                <span className="text-sm text-gray-300">Push Notifications</span>
                <input type="checkbox" checked={settings.notifications_enabled} onChange={e => setSettings({...settings, notifications_enabled: e.target.checked})} className="w-5 h-5 accent-sentinel-accent" />
              </label>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Palette size={18} className="text-sentinel-accent" />Appearance</h3>
            <div className="space-y-2">
              <button onClick={() => setSettings({...settings, theme: 'dark'})} className={`w-full p-3 rounded-lg border text-left text-sm ${settings.theme === 'dark' ? 'border-sentinel-accent bg-sentinel-accent/10 text-white' : 'border-sentinel-600/30 text-gray-400'}`}>Dark Mode</button>
              <button onClick={() => setSettings({...settings, theme: 'light'})} className={`w-full p-3 rounded-lg border text-left text-sm ${settings.theme === 'light' ? 'border-sentinel-accent bg-sentinel-accent/10 text-white' : 'border-sentinel-600/30 text-gray-400'}`}>Light Mode</button>
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2"><Database size={18} className="text-sentinel-accent" />Data Source</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">Network</span><span className="text-gray-300">Ethereum Mainnet</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Provider</span><span className="text-gray-300">Alchemy</span></div>
              <div className="flex justify-between"><span className="text-gray-500">Status</span><span className="text-green-400 flex items-center gap-1"><span className="w-2 h-2 bg-green-400 rounded-full"></span>Connected</span></div>
            </div>
          </div>

          <button onClick={save} disabled={saving} className="w-full btn-primary py-3 flex items-center justify-center gap-2">
            <Save size={18} /> {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
