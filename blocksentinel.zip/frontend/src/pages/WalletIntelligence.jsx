import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Wallet, Activity, ArrowRightLeft, Users, Calendar } from 'lucide-react';
import { walletAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const WalletIntelligence = () => {
  const [address, setAddress] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const search = async (e) => {
    e.preventDefault();
    if (!address.startsWith('0x')) return;
    setLoading(true);
    try {
      const res = await walletAPI.intel(address);
      setData(res.data);
    } catch (err) {
      alert('Wallet analysis failed: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Wallet Intelligence</h1>
      <form onSubmit={search} className="flex gap-2">
        <input type="text" placeholder="Search wallet address (0x...)" className="input-field flex-1 font-mono" value={address} onChange={(e) => setAddress(e.target.value)} />
        <button type="submit" className="btn-primary" disabled={loading}><Search size={18} /></button>
      </form>
      {loading && <div className="text-center py-12 text-gray-500">Analyzing wallet on-chain...</div>}
      {data && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="card">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="text-sm text-gray-500 mb-1">Wallet Address</div>
                <div className="font-mono text-lg text-white">{data.address}</div>
              </div>
              <div className="text-right">
                <div className={`badge badge-${(data.riskLevel || 'low').toLowerCase()} text-sm`}>{data.riskLevel || 'LOW'}</div>
                <div className={`text-3xl font-bold mt-2 risk-${(data.riskLevel || 'low').toLowerCase()}`}>{data.riskScore || 0}<span className="text-lg text-gray-500">/100</span></div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-sentinel-900/50 p-4 rounded-lg"><Wallet size={18} className="text-sentinel-accent mb-2" /><div className="text-xl font-bold text-white">{data.balance?.toFixed(4) || '0'}</div><div className="text-xs text-gray-500">ETH Balance</div></div>
              <div className="bg-sentinel-900/50 p-4 rounded-lg"><Activity size={18} className="text-sentinel-accent mb-2" /><div className="text-xl font-bold text-white">{data.txCount?.toLocaleString() || '0'}</div><div className="text-xs text-gray-500">Transactions</div></div>
              <div className="bg-sentinel-900/50 p-4 rounded-lg"><Users size={18} className="text-sentinel-accent mb-2" /><div className="text-xl font-bold text-white">{data.counterpartyCount || 0}</div><div className="text-xs text-gray-500">Counterparties</div></div>
              <div className="bg-sentinel-900/50 p-4 rounded-lg"><Calendar size={18} className="text-sentinel-accent mb-2" /><div className="text-xl font-bold text-white">{data.walletAge || 'N/A'}</div><div className="text-xs text-gray-500">Wallet Age</div></div>
            </div>
          </div>
          {data.riskFactors?.length > 0 && (
            <div className="card">
              <h3 className="font-bold mb-4">Risk Factors</h3>
              <div className="space-y-2">
                {data.riskFactors.map((f, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-sentinel-900/50 rounded-lg">
                    <span className="text-sm text-gray-300">{f.name}</span>
                    <span className="text-sm font-bold text-sentinel-high">+{f.contribution}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2"><ArrowRightLeft size={18} className="text-sentinel-accent" />Recent Transfers</h3>
            {data.recentTransfers?.length === 0 ? <div className="text-gray-500 text-sm py-4">No recent transfers found</div> : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {data.recentTransfers.map((t, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-sentinel-900/50 rounded-lg">
                    <div className="font-mono text-sm text-gray-300">{(t.from || '').slice(0, 16)}... → {(t.to || '').slice(0, 16)}...</div>
                    <div className="text-sm font-mono text-white">{parseFloat(t.value || 0).toFixed(4)} ETH</div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="card">
            <h3 className="font-bold mb-4">Related Transactions</h3>
            {data.relatedTransactions?.length === 0 ? <div className="text-gray-500 text-sm py-4">No related transactions in database</div> : (
              <div className="space-y-2">
                {data.relatedTransactions.map((tx, i) => (
                  <div key={i} onClick={() => navigate(`/transactions/${tx.tx_hash}`)} className="flex items-center justify-between p-3 bg-sentinel-900/50 rounded-lg hover:bg-sentinel-700/30 cursor-pointer transition-all">
                    <div className="font-mono text-sm text-gray-300">{tx.tx_hash?.slice(0, 24)}...</div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-mono text-white">{parseFloat(tx.value_eth || 0).toFixed(4)} ETH</span>
                      <span className={`badge badge-${(tx.risk_level || 'low').toLowerCase()}`}>{tx.risk_level}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default WalletIntelligence;
