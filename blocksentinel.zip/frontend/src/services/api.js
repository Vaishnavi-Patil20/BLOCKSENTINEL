import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('blocksentinel-auth') ? 
    JSON.parse(localStorage.getItem('blocksentinel-auth')).state?.token : null;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('blocksentinel-auth');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;

export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  signup: (data) => api.post('/auth/signup', data),
  me: () => api.get('/auth/me'),
};

export const txAPI = {
  latest: (limit = 20) => api.get(`/transactions/latest?limit=${limit}`),
  get: (hash) => api.get(`/transactions/${hash}`),
  analyze: (txHash) => api.post('/transactions/analyze', { txHash }),
  risk: (hash) => api.get(`/transactions/${hash}/risk`),
};

export const walletAPI = {
  intel: (address) => api.get(`/wallets/${address}/intel`),
  transfers: (address) => api.get(`/wallets/${address}/transfers`),
};

export const alertAPI = {
  list: (params) => api.get('/alerts', { params }),
  stats: () => api.get('/alerts/stats'),
  updateStatus: (id, status) => api.patch(`/alerts/${id}/status`, { status }),
};

export const caseAPI = {
  list: (params) => api.get('/cases', { params }),
  get: (id) => api.get(`/cases/${id}`),
  create: (data) => api.post('/cases', data),
  update: (id, data) => api.patch(`/cases/${id}`, data),
};

export const analyticsAPI = {
  dashboard: () => api.get('/analytics/dashboard'),
  riskTrend: () => api.get('/analytics/risk-trend'),
};

export const auditAPI = {
  list: (limit = 100) => api.get(`/audit?limit=${limit}`),
  create: (data) => api.post('/audit', data),
};

export const settingsAPI = {
  get: () => api.get('/settings'),
  update: (data) => api.put('/settings', data),
};

export const searchAPI = {
  search: (q) => api.get(`/search?q=${encodeURIComponent(q)}`),
};
