import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      setAuth: (user, token) => set({ user, token, isAuthenticated: true }),
      logout: () => set({ user: null, token: null, isAuthenticated: false }),
    }),
    { name: 'blocksentinel-auth' }
  )
);

export const useAppStore = create((set) => ({
  sidebarOpen: true,
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  commandPaletteOpen: false,
  setCommandPalette: (v) => set({ commandPaletteOpen: v }),
  liveTransactions: [],
  addLiveTx: (tx) => set((s) => ({ liveTransactions: [tx, ...s.liveTransactions].slice(0, 100) })),
  wsStatus: { connected: false, source: 'none' },
  setWsStatus: (status) => set({ wsStatus: status }),
  dataSource: { network: 'Ethereum Mainnet', connected: false, block: 0 },
  setDataSource: (ds) => set({ dataSource: ds }),
  searchQuery: '',
  setSearchQuery: (q) => set({ searchQuery: q }),
}));
